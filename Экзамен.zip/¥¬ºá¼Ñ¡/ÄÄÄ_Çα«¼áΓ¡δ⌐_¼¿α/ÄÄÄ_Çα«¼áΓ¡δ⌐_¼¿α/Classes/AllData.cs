﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ООО_Ароматный_мир.Classes
{
    class AllData
    {
        public static int ID;
    }
}
