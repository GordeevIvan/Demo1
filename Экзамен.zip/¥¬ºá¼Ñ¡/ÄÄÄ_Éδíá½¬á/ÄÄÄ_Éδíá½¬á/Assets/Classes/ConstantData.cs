﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ООО_Рыбалка.Assets.Classes
{
    class ConstantData
    {
        public static Windows.Authorization auth;
        public static string Atricle;
        public static MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection("server=localhost;user=root;pwd=Ivan2004;database=ooo_fish");
    }
}
